(function () {
  "use strict";
  const HOST_ID = "midroll-helper-host";
  const old = globalThis.MidrollPanelHost || document.getElementById(HOST_ID);
  if (old) {
    globalThis.MidrollStudio.mountPanel(old);
    old.hidden = false;
    globalThis.MidrollRefreshDuration?.();
    old.shadowRoot?.querySelector("#interval")?.focus();
    return;
  }
  const P = globalThis.MidrollPlanner;
  const host = document.createElement("div");
  globalThis.MidrollPanelHost = host;
  host.id = HOST_ID;
  host.style.cssText = "position:fixed;right:18px;top:18px;width:360px;max-width:calc(100vw - 36px);z-index:2147483647;color-scheme:light;";
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      :host { all: initial; font-family: Arial, sans-serif; }
      * { box-sizing: border-box; }
      .panel { color: #233149; background: #fff; border: 1px solid #d4dfec; border-radius: 16px; box-shadow: 0 12px 48px #12203938; max-height: calc(100vh - 36px); overflow: auto; font-size: 14px; line-height: 1.5; }
      header { padding: 18px 20px; border-bottom: 1px solid #e7edf5; display: flex; gap: 8px; align-items: start; }
      h2 { margin: 0; font-size: 17px; line-height: 1.4; }
      .subtitle { color: #596a80; font-size: 12px; margin: 3px 0 0; }
      #close { margin-left: auto; padding: 2px 7px; border: 0; background: none; font-size: 22px; color: #596a80; }
      main { padding: 18px 20px 20px; }
      .rules { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; }
      .pill { background: #eff5ff; color: #23529b; border-radius: 7px; padding: 4px 8px; font-size: 12px; }
      label { display: block; font-weight: 600; margin-bottom: 6px; }
      input { width: 100%; border: 1px solid #b9c8da; border-radius: 8px; padding: 10px 12px; color: #233149; background: #fff; font: inherit; }
      input:focus { outline: 2px solid #c0d8ff; border-color: #1967d2; }
      .stepper { display: grid; grid-template-columns: 40px 1fr 40px; gap: 6px; }
      .stepper button { padding: 8px; font-size: 20px; user-select: none; }
      .help { font-size: 12px; color: #64748b; margin: 6px 0 12px; }
      #duration { display: block; padding: 10px 12px; border-radius: 8px; background: #eff5ff; font-weight: 600; }
      button { cursor: pointer; font: inherit; border-radius: 8px; padding: 10px 12px; font-weight: 600; border: 1px solid #c4d2e3; color: #233149; background: #f8fafc; }
      button:focus-visible { outline: 2px solid #1967d2; outline-offset: 2px; }
      button:disabled { opacity: .5; cursor: default; }
      .actions { display: grid; gap: 8px; grid-template-columns: 1fr 1fr; margin-top: 14px; }
      .primary { background: #1967d2; color: #fff; border-color: #1967d2; }
      #stop { color: #a72428; border-color: #e7babc; width: 100%; margin-top: 8px; }
      [hidden] { display: none !important; }
      #status { padding: 11px 12px; border-radius: 8px; background: #f1f5f9; white-space: pre-line; margin-top: 14px; font-size: 13px; }
      #status[data-tone="error"] { background: #fff1f0; color: #9b2723; }
      #status[data-tone="success"] { background: #edf8f0; color: #23623a; }
      #preview { border-top: 1px solid #e7edf5; margin-top: 16px; padding-top: 14px; }
      #summary { font-size: 13px; margin: 0 0 8px; white-space: pre-line; }
      #times { list-style: none; padding: 0; margin: 0; display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; max-height: 170px; overflow: auto; }
      #times li { font: 12px monospace; text-align: center; border-radius: 6px; background: #f1f5f9; padding: 5px; }
      details { font-size: 12px; color: #596a80; margin-top: 14px; }
      summary { cursor: pointer; }
      details label { margin-top: 10px; }
      details input { font-size: 13px; }
      #diagnose { width: 100%; margin-top: 10px; font-size: 12px; }
      textarea { margin-top: 8px; width: 100%; height: 110px; font: 11px monospace; border: 1px solid #c4d2e3; border-radius: 6px; padding: 8px; }
      footer { color: #64748b; font-size: 11px; padding-top: 14px; }
    </style>
    <section class="panel" aria-label="Chèn điểm quảng cáo YouTube">
        <header><div><h2>Chèn điểm quảng cáo</h2><p class="subtitle">Một video · Bạn tự xem lại và lưu · v0.1.6</p></div><button id="close" type="button" title="Ẩn bảng điều khiển" aria-label="Ẩn bảng điều khiển">×</button></header>
      <main>
        <div class="rules"><span class="pill">Bắt đầu 01:00</span><span class="pill">Chừa 60 giây cuối</span><span class="pill">Giữ điểm cũ</span></div>
        <label for="interval">Khoảng cách giữa các điểm (giây)</label>
        <div class="stepper"><button id="decrease" type="button" aria-label="Giảm 1 giây" title="Giảm 1 giây">−</button><input id="interval" type="text" value="120" inputmode="numeric" autocomplete="off" spellcheck="false"><button id="increase" type="button" aria-label="Tăng 1 giây" title="Tăng 1 giây">+</button></div>
        <p class="help">Ví dụ 120 giây: 01:00, 03:00, 05:00…</p>
        <label for="duration">Độ dài video · tự động</label>
        <output id="duration" aria-live="polite">Đang đọc…</output>
        <p class="help">Extension tự đọc độ dài video đang mở từ YouTube Studio.</p>
        <div class="actions"><button id="read">Xem trước</button><button id="start" class="primary" disabled>Chèn điểm</button></div>
        <button id="stop" hidden>Dừng chèn</button>
        <div id="status" role="status" aria-live="polite">Mở Quản lý vị trí quảng cáo trong YouTube Studio, rồi bấm Xem trước.</div>
        <section id="preview" hidden><p id="summary"></p><ul id="times" aria-label="Các điểm sẽ thêm"></ul></section>
        <details id="advanced"><summary>Thông tin để hỗ trợ</summary>
          <button id="diagnose">Hiện thông tin để hỗ trợ</button>
          <textarea id="diagnostics" readonly hidden aria-label="Thông tin trình quảng cáo"></textarea>
        </details>
        <footer>Có thể dùng ứng dụng khác khi chèn. Chrome hiện thanh thông báo điều khiển tab trong lúc chạy.<br>Sau khi chèn, kiểm tra trong Studio rồi tự bấm Tiếp tục/Lưu.</footer>
      </main>
    </section>`;
  globalThis.MidrollStudio.mountPanel(host);
  // Keep text-entry keys inside the helper so Studio's bubbling shortcuts
  // do not intercept typing. Native text editing and Tab remain available.
  for (const type of ["keydown", "keyup", "keypress"]) {
    shadow.addEventListener(type, (event) => event.stopPropagation());
  }
  let mountTimer;
  const observer = new MutationObserver((records) => {
    const outsideChange = records.some((record) => {
      for (let node = record.target; node; node = node.parentNode || node.host) if (node === host) return false;
      return true;
    });
    if (!outsideChange) return;
    clearTimeout(mountTimer);
    mountTimer = setTimeout(() => globalThis.MidrollStudio.mountPanel(host), 100);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  const $ = (id) => shadow.getElementById(id);
  let plan = null;
  let adapter = null;
  let controller = null;
  let durationController = null;
  let panelRoute = location.pathname;
  let touched = false;

  function status(message, tone = "") {
    $("status").textContent = message;
    $("status").dataset.tone = tone;
  }
  function invalidate() {
    plan = null;
    adapter = null;
    $("start").disabled = true;
    $("preview").hidden = true;
  }
  function busy(value) {
    $("interval").disabled = value;
    $("decrease").disabled = value;
    $("increase").disabled = value;
    $("read").disabled = value || Boolean(durationController);
    $("diagnose").disabled = value;
    $("close").disabled = value;
    $("stop").hidden = !value;
    $("stop").disabled = false;
    $("start").disabled = value || !plan?.additions.length;
  }

  chrome.storage.local.get({ intervalSeconds: 120 }).then((saved) => {
    if (!touched && /^\d+$/.test(String(saved.intervalSeconds)) && Number(saved.intervalSeconds) > 0) {
      $("interval").value = saved.intervalSeconds;
    }
  }).catch(() => {});
  $("interval").addEventListener("input", () => { touched = true; invalidate(); });
  function stepInterval(direction) {
    if ($("interval").disabled) return;
    const text = $("interval").value.trim();
    const value = Number(text);
    if (!/^\d+$/.test(text) || !Number.isSafeInteger(value) || value < 1) {
      status("Nhập số giây nguyên lớn hơn 0 trước khi tăng hoặc giảm.", "error");
      $("interval").focus();
      return;
    }
    const next = Math.max(1, value + direction);
    if (!Number.isSafeInteger(next)) return;
    $("interval").value = String(next);
    $("interval").dispatchEvent(new Event("input", { bubbles: true }));
    $("interval").focus();
  }
  // No press-and-hold timer or native number spinner: one click, one step.
  $("decrease").addEventListener("click", () => stepInterval(-1));
  $("increase").addEventListener("click", () => stepInterval(1));
  $("interval").addEventListener("keydown", (event) => {
    if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
    event.preventDefault();
    if (!event.repeat) stepInterval(event.key === "ArrowUp" ? 1 : -1);
  });
  $("close").addEventListener("click", () => {
    host.hidden = true;
    durationController?.abort();
    invalidate();
  });
  async function refreshDuration(preview = false) {
    if (controller) return;
    durationController?.abort();
    const reading = new AbortController();
    durationController = reading;
    panelRoute = location.pathname;
    invalidate();
    $("read").disabled = true;
    $("duration").textContent = "Đang đọc…";
    try {
      const found = await globalThis.MidrollStudio.createAdapter({
        signal: reading.signal,
        onDurationStatus: (message) => { if (durationController === reading) status(message); }
      });
      if (reading.signal.aborted || durationController !== reading) return;
      adapter = found;
      const current = adapter.snapshot();
      $("duration").textContent = P.formatTime(current.duration);
      if (!preview) {
        status("Đã đọc độ dài video. Chọn khoảng cách rồi bấm Xem trước.");
        return;
      }
      plan = { ...P.makePlan(current.duration, $("interval").value, current.times), fingerprint: current.fingerprint };
      chrome.storage.local.set({ intervalSeconds: plan.interval }).catch(() => {});
      $("summary").textContent = `Thời lượng: ${P.formatTime(plan.duration)} (tự động)\nGiữ ${plan.existing.length} điểm có sẵn · Bỏ qua ${plan.skipped.length} mốc gần/trùng\nSẽ thêm ${plan.additions.length} điểm:`;
      $("times").replaceChildren(...plan.additions.map((seconds) => {
        const item = document.createElement("li");
        item.textContent = P.formatTime(seconds);
        return item;
      }));
      $("preview").hidden = false;
      $("start").disabled = plan.additions.length === 0;
      status(plan.additions.length ? "Kiểm tra các mốc bên dưới, rồi bấm Chèn điểm." : "Các mốc dự kiến đều đã có điểm gần/trùng. Không cần thêm.");
    } catch (error) {
      if (reading.signal.aborted || durationController !== reading) return;
      invalidate();
      $("duration").textContent = "Chưa đọc được";
      status(error.message, "error");
    } finally {
      if (durationController === reading) {
        durationController = null;
        $("read").disabled = Boolean(controller);
      }
    }
  }
  globalThis.MidrollRefreshDuration = () => refreshDuration(false);
  $("read").addEventListener("click", () => { touched = true; void refreshDuration(true); });
  // Studio is a single-page app; don't leave the old video's length visible
  // after navigation. A new preview always reads the current video again.
  const routeObserver = new MutationObserver(() => {
    if (location.pathname !== panelRoute) {
      panelRoute = location.pathname;
      durationController?.abort();
      invalidate();
      $("duration").textContent = "Đang đọc…";
      if (!host.hidden && !controller) void refreshDuration(false);
    }
  });
  routeObserver.observe(document.documentElement, { childList: true, subtree: true });

  $("start").addEventListener("click", async () => {
    if (!plan || controller) return;
    const currentPlan = plan;
    const currentAdapter = adapter;
    controller = new AbortController();
    busy(true);
    let inserted = 0;
    status("Đang bật chế độ chạy nền cho tab Studio…");
    try {
      const result = await globalThis.MidrollBackgroundClient.run(({ signal }) => globalThis.MidrollRunner.runPlan(currentAdapter, currentPlan, {
        signal,
        onWaiting: ({ inserted: count, total, seconds, message }) => {
          status(`${message}\nĐã xác nhận ${count}/${total} điểm${Number.isFinite(seconds) ? ` · Mốc đang xử lý: ${P.formatTime(seconds)}` : ""}. Chưa lưu.`);
        },
        onProgress: (progress) => {
          inserted = progress.inserted;
          status(`Đã thêm ${progress.inserted}/${progress.total} điểm. Mốc vừa xử lý: ${P.formatTime(progress.seconds)}.\nChưa lưu thay đổi.`);
        }
      }), { signal: controller.signal });
      status(`Đã xác nhận thêm ${result.inserted} điểm; giữ các điểm cũ.${result.skipped ? ` Bỏ qua thêm ${result.skipped} mốc đã có.` : ""}\nBạn hãy kiểm tra trong Studio, rồi tự bấm Tiếp tục/Lưu.`, "success");
    } catch (error) {
      const stopped = error.name === "AbortError";
      status(`${stopped ? "Đã dừng theo yêu cầu." : error.message}\nĐã xác nhận thêm ${inserted} điểm; chưa lưu. Kiểm tra cả điểm cuối đang nhập. Các điểm đã thêm vẫn nằm trong bản chỉnh sửa Studio.`, stopped ? "" : "error");
    } finally {
      controller = null;
      invalidate();
      busy(false);
    }
  });
  $("stop").addEventListener("click", () => {
    controller?.abort();
    $("stop").disabled = true;
    status("Đang dừng… Chưa lưu; các điểm đã thêm vẫn nằm trong bản chỉnh sửa.");
  });
  $("diagnose").addEventListener("click", () => {
    try {
      $("diagnostics").value = JSON.stringify(globalThis.MidrollStudio.diagnostics(), null, 2);
      $("diagnostics").hidden = false;
      $("diagnostics").focus();
      $("diagnostics").select();
    } catch (error) { status(error.message, "error"); }
  });
  $("interval").focus();
  void refreshDuration(false);
})();
