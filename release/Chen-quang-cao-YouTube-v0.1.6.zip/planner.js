(function (root) {
  "use strict";
  const START = 60;
  const END_MARGIN = 60;
  const MIN_DURATION = 480;
  const MAX_POINTS = 1000;
  const DUPLICATE_WINDOW = 1;

  function parseTime(value) {
    const text = String(value ?? "").trim();
    if (!/^\d{1,4}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?$/.test(text)) return null;
    const [whole, fraction = ""] = text.replace(",", ".").split(".");
    const parts = whole.split(":").map(Number);
    if (parts.slice(1).some((p) => p >= 60)) return null;
    return parts.reduce((sum, part) => sum * 60 + part, 0) + (fraction ? Number(`0.${fraction}`) : 0);
  }

  // Studio ad fields use M:SS:subsecond (e.g. 1:07:17), unlike a normal
  // H:MM:SS duration. Four-part fields use H:MM:SS:subsecond. Compare whole
  // seconds conservatively: no frame rate is assumed and old text is kept.
  function readStudioTime(value) {
    const text = String(value ?? "").trim();
    if (/^\d{1,4}:\d{2}:\d{2}:\d{2}$/.test(text)) return parseTime(text.slice(0, -3));
    if (/^\d{1,4}:\d{2}:\d{2}$/.test(text)) {
      const [minutes, seconds] = text.split(":").map(Number);
      return seconds < 60 ? minutes * 60 + seconds : null;
    }
    return parseTime(text);
  }

  function formatTime(seconds) {
    const value = Math.floor(seconds);
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor((value % 3600) / 60);
    const rest = value % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(hours)}:${pad(minutes)}:${pad(rest)}`;
  }

  function formatLike(seconds, sample) {
    const full = formatTime(seconds);
    const text = String(sample).trim();
    if (/^\d{2,4}:\d{2}:\d{2}:\d{2}$/.test(text)) return `${full}:00`;
    const parts = text.split(/[.,]/)[0].split(":").length;
    let result = parts === 2 ? `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${full.slice(-2)}` : full;
    const fraction = text.match(/([.,])(\d{1,3})$/);
    if (fraction) result += fraction[1] + "0".repeat(fraction[2].length);
    return result;
  }

  function formatStudioTime(seconds, sample) {
    const text = String(sample).trim();
    if (/^\d{1,4}:\d{2}:\d{2}:\d{2}$/.test(text)) return `${formatTime(seconds)}:00`;
    if (/^\d{1,4}:\d{2}:\d{2}$/.test(text)) {
      const whole = Math.floor(seconds);
      const minutes = String(Math.floor(whole / 60)).padStart(text.split(":")[0].length, "0");
      return `${minutes}:${String(whole % 60).padStart(2, "0")}:00`;
    }
    return formatLike(seconds, sample);
  }

  function makePlan(duration, interval, existing = []) {
    if (!Number.isFinite(duration) || duration <= 0) throw new Error("Chưa đọc được tổng độ dài video. Hãy tải lại Studio, mở Quản lý vị trí quảng cáo rồi bấm Xem trước để tự đọc lại.");
    if (duration < MIN_DURATION) throw new Error("Video ngắn hơn 8 phút, không thuộc phạm vi quảng cáo giữa video của extension.");
    const raw = String(interval).trim();
    if (!/^\d+$/.test(raw) || !Number.isSafeInteger(Number(raw)) || Number(raw) <= 0) {
      throw new Error("Khoảng cách phải là số giây nguyên lớn hơn 0.");
    }
    const step = Number(raw);
    if (!Array.isArray(existing) || existing.some((s) => !Number.isFinite(s) || s < 0 || s > duration)) {
      throw new Error("Không đọc được đầy đủ các mốc quảng cáo hiện có. Extension dừng để bạn kiểm tra.");
    }
    const end = duration - END_MARGIN;
    const count = Math.max(0, Math.floor((end - START) / step) + 1);
    if (count > MAX_POINTS) throw new Error(`Có hơn ${MAX_POINTS} mốc dự kiến. Hãy tăng khoảng cách để chia việc chèn thành số lượng hợp lý.`);
    const proposed = Array.from({ length: count }, (_, index) => START + index * step);
    const skipped = proposed.filter((s) => existing.some((old) => Math.abs(old - s) <= DUPLICATE_WINDOW));
    const additions = proposed.filter((s) => !skipped.includes(s));
    return { duration, interval: step, existing: [...existing], proposed, skipped, additions };
  }

  function preserves(before, after) {
    const remaining = [...after];
    for (const value of before) {
      const index = remaining.findIndex((current) => current === value);
      if (index < 0) return false;
      remaining.splice(index, 1);
    }
    return true;
  }

  // Return the one extra occurrence, not just a value absent from before.
  // Duplicate timecodes are valid; every old occurrence must still exist.
  function additionalKey(before, after) {
    if (after.length !== before.length + 1) return null;
    const counts = new Map();
    for (const key of before) counts.set(key, (counts.get(key) || 0) + 1);
    let extra = null;
    for (const key of after) {
      const count = counts.get(key) || 0;
      if (count) counts.set(key, count - 1);
      else if (extra === null) extra = key;
      else return null;
    }
    return [...counts.values()].every((count) => count === 0) ? extra : null;
  }

  const api = { START, END_MARGIN, MIN_DURATION, MAX_POINTS, DUPLICATE_WINDOW, parseTime, readStudioTime, formatTime, formatLike, formatStudioTime, makePlan, preserves, additionalKey };
  root.MidrollPlanner = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(globalThis);
