(function (root) {
  "use strict";
  const P = root.MidrollPlanner;
  const BUTTONS = 'button, [role="button"], ytcp-button, ytcp-icon-button';
  const INPUTS = 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea';
  const INSERT = /^(?:chen|them) (?:(?:vi tri|diem) )?quang cao$|^insert ad (?:slot|break)$/;
  const REMOVE = /^xoa(?: (?:vi tri|diem)?\s*quang cao.*)?$|^delete(?: ad (?:slot|break).*)?$|^remove ad (?:slot|break).*$/;
  let lastInsertion = null;

  function normalize(text) {
    return String(text || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().replace(/^\s*\+\s*/, "").replace(/\s+/g, " ").trim();
  }

  function parent(element) {
    return element.parentElement || element.getRootNode()?.host || null;
  }

  function inside(element, ancestor) {
    for (let current = element; current; current = parent(current)) if (current === ancestor) return true;
    return false;
  }

  function query(scope, selector) {
    const result = [];
    function walk(node) {
      result.push(...node.querySelectorAll(selector));
      for (const element of node.querySelectorAll("*")) {
        if (element.id === "midroll-helper-host") continue;
        if (element.shadowRoot) walk(element.shadowRoot);
      }
    }
    walk(scope);
    return result.filter((element) => {
      for (let current = element; current; current = parent(current)) {
        if (current.id === "midroll-helper-host") return false;
      }
      return true;
    });
  }

  function visible(element) {
    if (!element.isConnected) return false;
    for (let current = element; current; current = parent(current)) {
      if (current.hidden || current.getAttribute("aria-hidden") === "true") return false;
      const style = getComputedStyle(current);
      if (style.display === "none" || style.visibility === "hidden") return false;
    }
    if (element.getClientRects().length > 0) return true;
    // Some dialog shells use display:contents and do not have their own box.
    return getComputedStyle(element).display === "contents" && [...element.children].some(visible);
  }

  function matchesLabel(element, pattern) {
    return [element.getAttribute("aria-label"), element.getAttribute("title"), element.textContent]
      .some((text) => pattern.test(normalize(text)));
  }

  function buttons(scope, pattern) {
    const found = query(scope, BUTTONS).filter((element) => visible(element) && matchesLabel(element, pattern));
    // Polymer buttons can contain a native button with the same label.
    return found.filter((element) => !found.some((other) => other !== element && inside(other, element)));
  }

  function enabled(element) {
    for (let current = element; current; current = parent(current)) {
      if (current.disabled || current.hasAttribute("disabled") || current.getAttribute("aria-disabled") === "true") return false;
    }
    return true;
  }

  function editorScope() {
    const insertButtons = buttons(document, INSERT);
    if (insertButtons.length !== 1) throw new Error("Hãy mở Kiếm tiền → Quản lý vị trí quảng cáo, để nút Chèn vị trí quảng cáo xuất hiện. Nếu đã mở, giao diện này chưa được nhận diện.");
    const insert = insertButtons[0];
    let current = parent(insert);
    while (current && current !== document.body) {
      if (current.getAttribute("role") === "dialog" || ["ytcp-dialog", "dialog", "tp-yt-paper-dialog", "paper-dialog"].includes(current.localName) || /ad-breaks.*(?:dialog|editor)|(?:dialog|editor).*ad-breaks/.test(current.localName)) {
        return { scope: current, insert };
      }
      current = parent(current);
    }
    throw new Error("Chưa nhận diện được hộp quản lý vị trí quảng cáo. Hãy mở hộp này trước khi chạy extension.");
  }

  function fields(scope) {
    return query(scope, INPUTS).filter((element) => visible(element) && P.readStudioTime(element.value) !== null);
  }

  function adRows(scope) {
    const candidates = fields(scope);
    const rows = [];
    for (const input of candidates) {
      for (let container = parent(input); container && container !== scope; container = parent(container)) {
        const deletes = buttons(container, REMOVE);
        if (deletes.length === 1 && fields(container).length === 1) {
          rows.push({ element: container, input, remove: deletes[0], raw: input.value.trim(), seconds: P.readStudioTime(input.value) });
          break;
        }
        if (deletes.length > 1) break;
      }
    }
    const removes = buttons(scope, REMOVE);
    if (removes.length !== rows.length || new Set(rows.map((row) => row.remove)).size !== rows.length) {
      throw new Error("Không đọc được toàn bộ các ô thời gian quảng cáo hiện có. Extension chưa hỗ trợ cấu trúc này; chưa thay đổi điểm nào.");
    }
    if (rows.some((row) => !enabled(row.input) || row.input.readOnly)) {
      throw new Error("Một số điểm quảng cáo đang bị khóa hoặc chưa tải xong. Hãy chờ Studio tải xong rồi Xem trước lại.");
    }
    return rows;
  }

  const TIME_TOKEN = '\\d{1,4}:\\d{2}(?::\\d{2})?(?::\\d{2}|[.,]\\d{1,3})?';
  const TOTAL_LABEL = /(?:thoi luong|tong (?:do dai|thoi gian|thoi luong)|do dai video|video duration|total duration|duration)/;

  function durationLabel(node) {
    return [node.getAttribute("aria-label"), node.getAttribute("title"), node.getAttribute("placeholder")]
      .some((label) => TOTAL_LABEL.test(normalize(label)));
  }

  function labeledTime(text) {
    const match = normalize(text).match(new RegExp(`(?:thoi luong(?: video)?|tong (?:do dai|thoi gian|thoi luong)(?: video)?|do dai video|(?:video |total )?duration)\\s*:?\\s*(${TIME_TOKEN})$`));
    return match ? P.readStudioTime(match[1]) : null;
  }

  function automaticDuration(scope) {
    function unique(values, message) {
      const valid = values.filter((s) => Number.isFinite(s) && s > 0);
      if (!valid.length) return null;
      if (Math.max(...valid) - Math.min(...valid) > 1) throw new Error(message);
      return Math.max(...valid);
    }
    // Metadata can remain available even when Studio hides its <video>.
    const media = unique(query(scope, "video").map((video) => video.duration), "Studio đang hiển thị nhiều độ dài video khác nhau. Hãy kiểm tra đúng video.");
    if (media !== null) return media;

    const rowContainers = [];
    for (const field of query(scope, INPUTS)) {
      for (let container = parent(field); container && container !== scope; container = parent(container)) {
        const deletes = buttons(container, REMOVE);
        if (deletes.length === 1) { rowContainers.push(container); break; }
        if (deletes.length > 1) break;
      }
    }
    const isDurationControl = (node) => visible(node) && !rowContainers.some((row) => inside(node, row));
    const displayed = query(scope, '.ytp-time-duration, [class*="duration"], [id*="duration"]')
      .filter(isDurationControl).flatMap((node) => [node.matches('.ytp-time-duration') ? P.parseTime(node.textContent.trim()) : P.readStudioTime(node.textContent.trim()), labeledTime(node.textContent), P.readStudioTime(node.value)]);
    for (const node of query(scope, 'span, div, label, time, input, [aria-label], [title]').filter(isDurationControl)) {
      // Nested spans are common: current time / total time. Do not require
      // a leaf node, but accept only the entire time readout, not page prose.
      const text = node.textContent.trim().replace(/\s+/g, " ");
      const total = text.match(new RegExp(`^${TIME_TOKEN}\\s*/\\s*(${TIME_TOKEN})$`));
      if (total) displayed.push(P.readStudioTime(total[1]));
      displayed.push(labeledTime(text), labeledTime(node.getAttribute("aria-label")), labeledTime(node.getAttribute("title")));
      if (durationLabel(node)) displayed.push(P.readStudioTime(node.value));
    }
    const inDialog = unique(displayed, "Chưa xác định được tổng độ dài video: Studio hiển thị các giá trị khác nhau. Hãy kiểm tra lại video.");
    if (inDialog !== null) return inDialog;

    // A player may live outside the ad dialog. Restrict this fallback to
    // explicitly named visible duration controls, never arbitrary timecodes.
    const outside = query(document, '.ytp-time-duration, ytcp-video-info .duration, ytcp-video-info [class*="duration"], ytcp-video-player [class*="duration"]')
      .filter((node) => visible(node) && !inside(node, scope))
      .flatMap((node) => [node.matches('.ytp-time-duration') ? P.parseTime(node.textContent.trim()) : P.readStudioTime(node.textContent.trim()), labeledTime(node.textContent)]);
    return unique(outside, "Có nhiều tổng độ dài video ngoài hộp quảng cáo. Hãy mở đúng một video rồi thử lại.");
  }

  function mountPanel(host) {
    // Place the UI INSIDE the active ad dialog. Being outside its focus
    // trap or native modal top layer makes otherwise enabled inputs unusable.
    let container;
    try { container = editorScope().scope; } catch { container = document.body || document.documentElement; }
    if (host.parentNode !== container) container.append(host);
  }

  function setTime(input, seconds) {
    const text = P.formatStudioTime(seconds, input.value);
    const proto = input.localName === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    // Element focus/blur events can be absent in an inactive document.
    // Supply only missing events, and never bring Chrome to the foreground.
    const seen = new Set();
    const capture = (event) => { if (event.target === input) seen.add(event.type); };
    const types = ["focus", "focusin", "blur", "focusout"];
    for (const type of types) input.addEventListener(type, capture);
    const emitMissing = (type) => {
      if (!seen.has(type)) input.dispatchEvent(new FocusEvent(type, { bubbles: type === "focusin" || type === "focusout", composed: true }));
    };
    try {
      input.focus({ preventScroll: true });
      emitMissing("focus");
      emitMissing("focusin");
      setter.call(input, text);
      input.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: text }));
      input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      // Never send Enter: it could submit the whole dialog.
      input.blur();
      emitMissing("blur");
      emitMissing("focusout");
    } finally {
      for (const type of types) input.removeEventListener(type, capture);
    }
  }

  const waitFor = (check, options) => root.MidrollWait.waitFor(check, options);

  async function createAdapter({ signal, onDurationStatus = () => {}, timeout = 10000 } = {}) {
    const { scope } = editorScope();
    const route = location.pathname;
    const videoId = route.match(/^\/video\/([A-Za-z0-9_-]+)\//)?.[1];
    if (!videoId) throw new Error("Hãy mở một video trong YouTube Studio rồi mở Quản lý vị trí quảng cáo để tự đọc độ dài.");
    const started = Date.now();
    let duration = null;
    let source = "studio";
    let lastReason = "metadata-pending";

    function assertContext() {
      if (location.pathname !== route || !scope.isConnected || !visible(scope)) {
        throw new Error("Bạn đã đổi video hoặc đóng trình quảng cáo. Đã dừng; hãy mở lại và Xem trước.");
      }
      const current = editorScope();
      if (current.scope !== scope) throw new Error("Trình quảng cáo đã được mở lại. Hãy Xem trước lại.");
      return current.insert;
    }

    while (Date.now() - started < timeout) {
      signal?.throwIfAborted();
      assertContext();
      onDurationStatus("Đang tự đọc tổng độ dài video từ YouTube Studio…");
      let metadata;
      let readerTimer;
      try {
        metadata = await Promise.race([
          chrome.runtime.sendMessage({ type: "MIDROLL_READ_DURATION" }),
          new Promise((resolve) => { readerTimer = setTimeout(() => resolve({ seconds: null, reason: "reader-unavailable" }), 1500); })
        ]);
      } catch { metadata = { seconds: null, reason: "reader-unavailable" }; }
      finally { clearTimeout(readerTimer); }
      signal?.throwIfAborted();
      assertContext();
      if (metadata?.videoId === videoId && Number.isFinite(metadata.seconds) && metadata.seconds > 0) {
        duration = metadata.seconds;
        source = "player";
        break;
      }
      lastReason = metadata?.reason || "metadata-pending";
      // Conflicting identity-checked metadata must not be replaced by a
      // guessed UI time. A wrong-video response is never trusted.
      if (lastReason !== "duration-conflict") {
        try { duration = automaticDuration(scope); } catch { lastReason = "duration-conflict"; }
        if (duration !== null) break;
      }
      await new Promise((resolve) => setTimeout(resolve, 300));
    }
    if (duration === null) throw new Error(lastReason === "duration-conflict"
      ? "Các nguồn Studio báo độ dài video khác nhau. Chưa thay đổi điểm nào; hãy tải lại tab Studio rồi thử lại."
      : "Studio chưa cung cấp được tổng độ dài video. Chưa thay đổi điểm nào; hãy tải lại tab, mở Quản lý vị trí quảng cáo và bấm Xem trước để extension tự đọc lại.");

    function snapshot() {
      const insert = assertContext();
      const rows = adRows(scope);
      const keys = rows.map((row) => row.raw);
      const times = rows.map((row) => row.seconds);
      const outside = rows.find((row) => row.seconds > duration);
      if (outside) throw new Error(`Điểm có sẵn ${outside.raw} được đọc là ${P.formatTime(outside.seconds)}, vượt tổng độ dài ${P.formatTime(duration)} đọc từ Studio. Chưa thay đổi điểm nào; hãy kiểm tra định dạng mốc và video.`);
      return { rows, keys, times, insert, duration, source, fingerprint: JSON.stringify([route, duration, [...keys].sort()]) };
    }

    async function readyToConfirm({ signal, onPending } = {}) {
      // Studio's renderer may pause while fully hidden. Keep the same
      // pending operation instead of treating a self-assigned value as saved.
      await waitFor(() => { assertContext(); return !document.hidden; }, {
        signal, backgroundTimeout: Infinity, onPending
      });
    }

    async function insert(seconds, { signal, onWaiting = () => {} } = {}) {
      await readyToConfirm({ signal, onPending: onWaiting });
      const before = snapshot();
      lastInsertion = { target: P.formatTime(seconds), beforeCount: before.rows.length, phase: "seek", seek: null };
      if (!enabled(before.insert)) throw new Error("Nút Chèn vị trí quảng cáo đang bị khóa. Hãy kiểm tra Studio.");
      // When a separate playhead field exists, move it to the intended time.
      // Row inputs are excluded so an existing ad time cannot be overwritten.
      const playheads = fields(scope).filter((field) => !durationLabel(field) && !before.rows.some((row) => row.input === field));
      if (playheads.length > 1) throw new Error("Có nhiều ô thời gian ngoài danh sách quảng cáo. Không thể chọn chắc chắn ô đặt vị trí; đã dừng.");
      if (playheads.length === 1 && enabled(playheads[0]) && !playheads[0].readOnly) {
        setTime(playheads[0], seconds);
        await waitFor(() => P.readStudioTime(playheads[0].value) === seconds, { signal, stableFor: 300, onPending: onWaiting });
      }
      // An input value is not proof that Studio moved its timeline cursor.
      // Seek the actual preview when a supported player is available.
      const editorToken = crypto.randomUUID();
      scope.setAttribute("data-midroll-editor-token", editorToken);
      let seekTimer;
      let seek;
      try {
        seek = await Promise.race([
          chrome.runtime.sendMessage({ type: "MIDROLL_SEEK_PLAYHEAD", videoId, seconds, duration, editorToken }),
          new Promise((resolve) => { seekTimer = setTimeout(() => resolve({ ok: false, reason: "seek-timeout" }), 3000); })
        ]);
      } catch { seek = { ok: false, reason: "seek-unavailable" }; }
      finally {
        clearTimeout(seekTimer);
        if (scope.getAttribute("data-midroll-editor-token") === editorToken) scope.removeAttribute("data-midroll-editor-token");
      }
      signal?.throwIfAborted();
      assertContext();
      lastInsertion.seek = seek?.ok ? "confirmed" : seek?.reason || "no-response";
      if (!seek?.ok && seek?.reason !== "seek-unavailable") throw new Error("Chưa xác nhận được vị trí thanh thời gian trước khi chèn. Đã dừng; chưa thêm điểm ở lượt này.");
      const ready = snapshot();
      if (ready.fingerprint !== before.fingerprint) throw new Error("Danh sách quảng cáo đã thay đổi trước khi chèn. Hãy Xem trước lại.");
      // One click only. Never retry insertion on an ambiguous response.
      ready.insert.click();
      lastInsertion.phase = "identify";
      const oldInputs = new Set(before.rows.map((row) => row.input));
      let pendingReason = "Danh sách chưa xuất hiện điểm mới.";
      function selection() {
        assertContext();
        let current;
        try { current = adRows(scope); }
        catch (error) { pendingReason = error.message; return null; }
        if (current.length !== before.rows.length + 1) {
          pendingReason = `Danh sách đang có ${current.length} điểm; cần ${before.rows.length + 1} điểm sau một lần chèn.`;
          return null;
        }
        const keys = current.map((item) => item.raw);
        lastInsertion.currentCount = current.length;
        const extra = P.additionalKey(before.keys, keys);
        if (extra === null) {
          pendingReason = "Chưa đối chiếu được đầy đủ các mốc cũ sau khi Studio vẽ lại danh sách.";
          return null;
        }
        const fresh = current.filter((item) => !oldInputs.has(item.input));
        lastInsertion.newInputCount = fresh.length;
        lastInsertion.extraTime = extra;
        // A surviving input identity is stronger than its displayed value.
        // Otherwise require a unique occurrence of the extra raw timecode.
        const matches = current.filter((item) => item.raw === extra);
        const row = fresh.length === 1 && fresh[0].raw === extra ? fresh[0]
          : matches.length === 1 ? matches[0] : null;
        if (!row) {
          pendingReason = `Điểm mới được tạo tại vị trí thanh thời gian ${extra}, trùng điểm cũ; Studio đã thay toàn bộ các ô.${seek?.ok ? "" : " Chưa điều khiển được vị trí phát thực tế của giao diện này."}`;
          return null;
        }
        return { row, token: JSON.stringify([[...keys].sort(), current.indexOf(row), row.raw]) };
      }
      // Rerenders can expose a temporary default/duplicate or a partial list.
      // Wait for stable evidence instead of stopping on the first frame.
      const token = await waitFor(() => selection()?.token, {
        signal, timeout: 15000, stableFor: 400, onPending: onWaiting,
        timeoutMessage: () => `Không xác định chắc chắn ô mới tại mốc ${P.formatTime(seconds)} sau khi chờ Studio cập nhật. ${pendingReason} Đã dừng; chưa sửa ô chưa rõ và chưa lưu. Hãy kiểm tra điểm vừa thêm trước khi Xem trước lại.`
      });
      signal?.throwIfAborted();
      // Re-read after awaiting: the previous DOM input may be disconnected.
      const latest = selection();
      if (!latest || latest.token !== token) throw new Error(`Studio tiếp tục đổi danh sách tại mốc ${P.formatTime(seconds)}. Đã dừng; chưa sửa ô chưa rõ và chưa lưu. Hãy kiểm tra điểm vừa thêm.`);
      const row = latest.row;
      lastInsertion.phase = "edit";
      if (!enabled(row.input) || row.input.readOnly) throw new Error("Ô thời gian mới chưa cho phép nhập. Đã dừng; hãy kiểm tra điểm vừa thêm.");
      // Commit the new row itself, even if its initial displayed time matches
      // the target; the playhead display alone is not a model acknowledgment.
      setTime(row.input, seconds);
      await waitFor(() => {
        const current = snapshot();
        if (document.hidden) return false;
        return current.keys.length === before.keys.length + 1 && P.preserves(before.keys, current.keys) && current.times.includes(seconds) && current.fingerprint;
      }, { signal, stableFor: 400, backgroundTimeout: Infinity, onPending: onWaiting });
      lastInsertion.phase = "confirmed";
    }
    async function verifyPlan(plan, { signal, onWaiting = () => {} } = {}) {
      await waitFor(() => {
        const current = snapshot();
        if (document.hidden) return false;
        return plan.additions.every((seconds) => current.times.some((time) => Math.abs(time - seconds) <= P.DUPLICATE_WINDOW)) && current.fingerprint;
      }, { signal, stableFor: 400, backgroundTimeout: Infinity, onPending: onWaiting });
    }
    return { snapshot, insert, verifyPlan };
  }

  // Diagnostics contain only controls in the ad dialog, not video titles,
  // account identifiers, cookies, URLs, HTML dumps, or page-wide content.
  function diagnostics() {
    const { scope } = editorScope();
    return {
      version: "0.1.6",
      lastInsertion,
      editor: scope.localName,
      controls: query(scope, BUTTONS).filter(visible).map((node) => ({ tag: node.localName, label: node.getAttribute("aria-label") || node.getAttribute("title") || node.textContent.trim().slice(0, 100) })),
      timeFields: query(scope, INPUTS).filter(visible).map((node) => ({ tag: node.localName, label: node.getAttribute("aria-label") || "", value: P.readStudioTime(node.value) === null ? "(không phải thời gian)" : node.value }))
    };
  }
  root.MidrollStudio = { createAdapter, diagnostics, mountPanel };
})(globalThis);
