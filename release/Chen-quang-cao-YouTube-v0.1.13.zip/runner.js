(function (root) {
  "use strict";
  async function runPlan(adapter, plan, { signal, onProgress = () => {}, onWaiting = () => {} } = {}) {
    let inserted = 0;
    let skipped = 0;
    const baseline = adapter.snapshot();
    const expected = [...baseline.keys];
    if (baseline.fingerprint !== plan.fingerprint) throw new Error("Video hoặc danh sách quảng cáo đã đổi. Hãy bấm Xem trước lại.");
    for (const seconds of plan.additions) {
      signal?.throwIfAborted();
      const before = adapter.snapshot();
      if (!root.MidrollPlanner.preserves(expected, before.keys)) {
        throw new Error("Danh sách quảng cáo đã thay đổi trong lúc chèn. Đã dừng; hãy kiểm tra các mốc trong Studio.");
      }
      if (before.times.some((time) => Math.abs(time - seconds) <= root.MidrollPlanner.DUPLICATE_WINDOW)) {
        skipped++;
        onProgress({ inserted, skipped, total: plan.additions.length, seconds });
        continue;
      }
      // insert() only edits a newly created row. It never saves, deletes,
      // changes automatic ads, or rewrites an existing row.
      await adapter.insert(seconds, { signal, onWaiting: (message) => onWaiting({ inserted, total: plan.additions.length, seconds, message }) });
      const after = adapter.snapshot();
      if (!root.MidrollPlanner.preserves(before.keys, after.keys) || after.keys.length !== before.keys.length + 1) {
        throw new Error("Không xác nhận được việc giữ nguyên các điểm cũ. Đã dừng; chưa lưu. Hãy kiểm tra Studio.");
      }
      if (!after.times.some((time) => time === seconds)) throw new Error("Studio chưa xác nhận mốc vừa nhập. Đã dừng; chưa lưu.");
      expected.splice(0, expected.length, ...after.keys);
      inserted++;
      onProgress({ inserted, skipped, total: plan.additions.length, seconds });
    }
    signal?.throwIfAborted();
    if (adapter.verifyPlan) await adapter.verifyPlan(plan, { signal, onWaiting: (message) => onWaiting({ inserted, total: plan.additions.length, message }) });
    const final = adapter.snapshot();
    if (!root.MidrollPlanner.preserves(expected, final.keys)) throw new Error("Studio đã thay đổi mốc sau khi nhập. Đã dừng; kiểm tra toàn bộ danh sách trước khi lưu.");
    if (!plan.additions.every((seconds) => final.times.some((time) => Math.abs(time - seconds) <= root.MidrollPlanner.DUPLICATE_WINDOW))) {
      throw new Error("Danh sách cuối còn thiếu mốc dự kiến. Chưa lưu; hãy bấm Xem trước để kiểm tra lại.");
    }
    return { inserted, skipped };
  }
  root.MidrollRunner = { runPlan };
  if (typeof module !== "undefined" && module.exports) module.exports = root.MidrollRunner;
})(globalThis);
