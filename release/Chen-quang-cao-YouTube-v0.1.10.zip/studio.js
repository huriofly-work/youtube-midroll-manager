(function (root) {
  "use strict";
  const P = root.MidrollPlanner;
  const BUTTONS = 'button, [role="button"], ytcp-button, ytcp-icon-button';
  const INPUTS = 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea';
  const INSERT = /^(?:chen|them) (?:(?:vi tri|diem) )?quang cao$|^insert ad (?:slot|break)$/;
  const REMOVE = /^xoa(?: (?:vi tri|diem)?\s*quang cao.*)?$|^delete(?: ad (?:slot|break).*)?$|^remove ad (?:slot|break).*$/;
  let lastInsertion = null;

  function normalize(text) {
    return String(text || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().replace(/^\s*\+\s*/, "").replace(/\s+/g, " ").trim();
  }

  function parent(element) {
    return element.parentElement || element.getRootNode()?.host || null;
  }

  function inside(element, ancestor) {
    for (let current = element; current; current = parent(current)) if (current === ancestor) return true;
    return false;
  }

  function query(scope, selector) {
    const result = [];
    function walk(node) {
      result.push(...node.querySelectorAll(selector));
      for (const element of node.querySelectorAll("*")) {
        if (element.id === "midroll-helper-host") continue;
        if (element.shadowRoot) walk(element.shadowRoot);
      }
    }
    walk(scope);
    return result.filter((element) => {
      for (let current = element; current; current = parent(current)) {
        if (current.id === "midroll-helper-host") return false;
      }
      return true;
    });
  }

  function isVisible(element, styles) {
    if (!element.isConnected) return false;
    for (let current = element; current; current = parent(current)) {
      if (current.hidden || current.getAttribute("aria-hidden") === "true") return false;
      const style = styles?.get(current) || getComputedStyle(current);
      styles?.set(current, style);
      if (style.display === "none" || style.visibility === "hidden") return false;
    }
    if (element.getClientRects().length > 0) return true;
    // Some dialog shells use display:contents and do not have their own box.
    return getComputedStyle(element).display === "contents" && [...element.children].some((child) => isVisible(child, styles));
  }
  const visible = (element) => isVisible(element);

  function matchesLabel(element, pattern) {
    return [element.getAttribute("aria-label"), element.getAttribute("title"), element.textContent]
      .some((text) => pattern.test(normalize(text)));
  }

  function buttons(scope, pattern, styles) {
    const found = query(scope, BUTTONS).filter((element) => matchesLabel(element, pattern) && isVisible(element, styles));
    // Polymer buttons can contain a native button with the same label.
    const matched = new Set(found);
    const ancestors = new Set();
    for (const element of found) {
      for (let ancestor = parent(element); ancestor; ancestor = parent(ancestor)) {
        if (matched.has(ancestor)) ancestors.add(ancestor);
      }
    }
    return found.filter((element) => !ancestors.has(element));
  }

  function enabled(element) {
    for (let current = element; current; current = parent(current)) {
      if (current.disabled || current.hasAttribute("disabled") || current.getAttribute("aria-disabled") === "true") return false;
    }
    return true;
  }

  function editorScope() {
    const insertButtons = buttons(document, INSERT);
    if (insertButtons.length !== 1) throw new Error("Hãy mở Kiếm tiền → Quản lý vị trí quảng cáo, để nút Chèn vị trí quảng cáo xuất hiện. Nếu đã mở, giao diện này chưa được nhận diện.");
    const insert = insertButtons[0];
    let current = parent(insert);
    while (current && current !== document.body) {
      if (current.getAttribute("role") === "dialog" || ["ytcp-dialog", "dialog", "tp-yt-paper-dialog", "paper-dialog"].includes(current.localName) || /ad-breaks.*(?:dialog|editor)|(?:dialog|editor).*ad-breaks/.test(current.localName)) {
        return { scope: current, insert };
      }
      current = parent(current);
    }
    throw new Error("Chưa nhận diện được hộp quản lý vị trí quảng cáo. Hãy mở hộp này trước khi chạy extension.");
  }

  function fields(scope, styles) {
    return query(scope, INPUTS).filter((element) => P.readStudioTime(element.value) !== null && isVisible(element, styles));
  }

  function adRows(scope, allowLocked = false) {
    // Index controls once per read, including shadow ancestry. No cache is
    // retained across reads: DOM replacements and changed values stay visible.
    const styles = new WeakMap();
    const candidates = fields(scope, styles);
    const removes = buttons(scope, REMOVE, styles);
    const fieldCounts = new Map();
    const removeGroups = new Map();
    for (const input of candidates) {
      for (let container = parent(input); container && container !== scope; container = parent(container)) {
        fieldCounts.set(container, (fieldCounts.get(container) || 0) + 1);
      }
    }
    for (const remove of removes) {
      for (let container = parent(remove); container && container !== scope; container = parent(container)) {
        const group = removeGroups.get(container);
        if (group) group.push(remove); else removeGroups.set(container, [remove]);
      }
    }
    const rows = [];
    for (const input of candidates) {
      for (let container = parent(input); container && container !== scope; container = parent(container)) {
        const deletes = removeGroups.get(container) || [];
        if (deletes.length === 1 && fieldCounts.get(container) === 1) {
          rows.push({ element: container, input, remove: deletes[0], raw: input.value.trim(), seconds: P.readStudioTime(input.value) });
          break;
        }
        if (deletes.length > 1) break;
      }
    }
    if (removes.length !== rows.length || new Set(rows.map((row) => row.remove)).size !== rows.length) {
      throw new Error("Không đọc được toàn bộ các ô thời gian quảng cáo hiện có. Extension chưa hỗ trợ cấu trúc này; chưa thay đổi điểm nào.");
    }
    if (!allowLocked && rows.some((row) => !enabled(row.input) || row.input.readOnly)) {
      throw new Error("Một số điểm quảng cáo đang bị khóa hoặc chưa tải xong. Hãy chờ Studio tải xong rồi Xem trước lại.");
    }
    return rows;
  }

  function cleanupRows(scope, rows) {
    const manual = /\bthu cong\b|\bmanual\b/;
    const automatic = /\btu dong\b|\bautomatic(?:ally)?\b|\bauto(?:matic)?[-_ ]ad/;
    const poor = /it co kha nang (?:phan phat|hien thi|chay) quang cao|khong phu hop|unlikely to (?:serve|show) ads|low (?:ad )quality/;
    const pending = /dang (?:xet duyet|xu ly|kiem tra)|cho (?:xet duyet|xu ly)|under review|processing|review pending/;
    const count = new Map();
    const groupEvidence = new Map();
    const rowElements = new Set(rows.map((row) => row.element));
    const styles = new WeakMap();
    const shown = (node) => isVisible(node, styles);
    const inRow = (node) => { for (let current = node; current && current !== scope; current = parent(current)) if (rowElements.has(current)) return true; return false; };
    for (const row of rows) for (let node = row.element; node && node !== scope; node = parent(node)) count.set(node, (count.get(node) || 0) + 1);
    function labels(node) {
      return [node.getAttribute("aria-label"), node.getAttribute("title"), node.getAttribute("data-tooltip-text"), node.getAttribute("data-ad-type"), node.getAttribute("data-placement-type"), node.getAttribute("data-ad-source")].filter(Boolean).map(normalize);
    }
    function red(node) {
      const colors = [getComputedStyle(node).color, getComputedStyle(node).fill, node.getAttribute("fill")];
      return colors.some((color) => {
        const match = String(color).match(/^rgba?\(\s*(\d+)[, ]+\s*(\d+)[, ]+\s*(\d+)(?:[, /]+([\d.]+))?\s*\)$/);
        return match && Number(match[1]) >= 160 && Number(match[2]) <= 125 && Number(match[3]) <= 125 && Number(match[1]) > Number(match[2]) * 1.5 && (match[4] === undefined || Number(match[4]) > 0);
      });
    }
    return rows.map((row) => {
      // Include status siblings around the time/delete controls, but never
      // read another row's warning or the dialog-wide automatic toggle.
      let container = row.element;
      for (let node = row.element; node && node !== scope && count.get(node) === 1; node = parent(node)) {
        container = node;
        if (/(?:^|[\s-])(?:ad-break(?:-row|-item)?|ad-row)(?:\s|$)/.test(node.localName + " " + node.getAttribute("class"))) break;
      }
      const nodes = [container, ...query(container, "*")].filter(shown);
      const evidence = nodes.flatMap((node) => [...labels(node), ...(node.childElementCount === 0 ? [normalize(node.textContent)] : [])]);
      let origin = evidence.filter((text) => manual.test(text) || automatic.test(text));
      // A labelled manual/automatic list can classify otherwise unlabelled
      // rows. Only headings/accessible labels are used, never all list text.
      if (!origin.length) {
        for (let group = parent(container); group && group !== scope; group = parent(group)) {
          if (!groupEvidence.has(group)) {
            const headings = query(group, 'h1, h2, h3, h4, legend, [role="heading"]').filter((node) => shown(node) && !inRow(node));
            groupEvidence.set(group, [...labels(group), ...headings.map((node) => normalize(node.textContent))]);
          }
          const groupLabels = groupEvidence.get(group);
          origin = groupLabels.filter((text) => manual.test(text) || automatic.test(text));
          if (origin.length) break;
        }
      }
      const hasManual = origin.some((text) => manual.test(text));
      const hasAutomatic = origin.some((text) => automatic.test(text));
      const kind = hasManual && !hasAutomatic ? "manual" : hasAutomatic && !hasManual ? "automatic" : "unknown";
      const warning = evidence.some((text) => poor.test(text)) || nodes.some((node) => {
        const name = normalize([node.getAttribute("icon"), node.getAttribute("data-icon"), node.id, node.getAttribute("class"), ...labels(node)].join(" "));
        return /warning|report[-_ ]problem|error[-_ ]outline|canh bao/.test(name) && [node, ...query(node, "svg, path")].some(red);
      });
      const reviewing = evidence.some((text) => pending.test(text)) || nodes.some((node) => node.getAttribute("aria-busy") === "true" || /spinner|progress/.test(node.localName));
      return { ...row, kind, warning, pending: reviewing };
    });
  }

  const TIME_TOKEN = '\\d{1,4}:\\d{2}(?::\\d{2})?(?::\\d{2}|[.,]\\d{1,3})?';
  const TOTAL_LABEL = /(?:thoi luong|tong (?:do dai|thoi gian|thoi luong)|do dai video|video duration|total duration|duration)/;

  function durationLabel(node) {
    return [node.getAttribute("aria-label"), node.getAttribute("title"), node.getAttribute("placeholder")]
      .some((label) => TOTAL_LABEL.test(normalize(label)));
  }

  function labeledTime(text) {
    const match = normalize(text).match(new RegExp(`(?:thoi luong(?: video)?|tong (?:do dai|thoi gian|thoi luong)(?: video)?|do dai video|(?:video |total )?duration)\\s*:?\\s*(${TIME_TOKEN})$`));
    return match ? P.readStudioTime(match[1]) : null;
  }

  function automaticDuration(scope) {
    function unique(values, message) {
      const valid = values.filter((s) => Number.isFinite(s) && s > 0);
      if (!valid.length) return null;
      if (Math.max(...valid) - Math.min(...valid) > 1) throw new Error(message);
      return Math.max(...valid);
    }
    // Metadata can remain available even when Studio hides its <video>.
    const media = unique(query(scope, "video").map((video) => video.duration), "Studio đang hiển thị nhiều độ dài video khác nhau. Hãy kiểm tra đúng video.");
    if (media !== null) return media;

    const rowContainers = [];
    for (const field of query(scope, INPUTS)) {
      for (let container = parent(field); container && container !== scope; container = parent(container)) {
        const deletes = buttons(container, REMOVE);
        if (deletes.length === 1) { rowContainers.push(container); break; }
        if (deletes.length > 1) break;
      }
    }
    const isDurationControl = (node) => visible(node) && !rowContainers.some((row) => inside(node, row));
    const displayed = query(scope, '.ytp-time-duration, [class*="duration"], [id*="duration"]')
      .filter(isDurationControl).flatMap((node) => [node.matches('.ytp-time-duration') ? P.parseTime(node.textContent.trim()) : P.readStudioTime(node.textContent.trim()), labeledTime(node.textContent), P.readStudioTime(node.value)]);
    for (const node of query(scope, 'span, div, label, time, input, [aria-label], [title]').filter(isDurationControl)) {
      // Nested spans are common: current time / total time. Do not require
      // a leaf node, but accept only the entire time readout, not page prose.
      const text = node.textContent.trim().replace(/\s+/g, " ");
      const total = text.match(new RegExp(`^${TIME_TOKEN}\\s*/\\s*(${TIME_TOKEN})$`));
      if (total) displayed.push(P.readStudioTime(total[1]));
      displayed.push(labeledTime(text), labeledTime(node.getAttribute("aria-label")), labeledTime(node.getAttribute("title")));
      if (durationLabel(node)) displayed.push(P.readStudioTime(node.value));
    }
    const inDialog = unique(displayed, "Chưa xác định được tổng độ dài video: Studio hiển thị các giá trị khác nhau. Hãy kiểm tra lại video.");
    if (inDialog !== null) return inDialog;

    // A player may live outside the ad dialog. Restrict this fallback to
    // explicitly named visible duration controls, never arbitrary timecodes.
    const outside = query(document, '.ytp-time-duration, ytcp-video-info .duration, ytcp-video-info [class*="duration"], ytcp-video-player [class*="duration"]')
      .filter((node) => visible(node) && !inside(node, scope))
      .flatMap((node) => [node.matches('.ytp-time-duration') ? P.parseTime(node.textContent.trim()) : P.readStudioTime(node.textContent.trim()), labeledTime(node.textContent)]);
    return unique(outside, "Có nhiều tổng độ dài video ngoài hộp quảng cáo. Hãy mở đúng một video rồi thử lại.");
  }

  function mountPanel(host) {
    // Place the UI INSIDE the active ad dialog. Being outside its focus
    // trap or native modal top layer makes otherwise enabled inputs unusable.
    let container;
    try { container = editorScope().scope; } catch { container = document.body || document.documentElement; }
    if (host.parentNode !== container) container.append(host);
  }

  function setTime(input, seconds) {
    const text = P.formatStudioTime(seconds, input.value);
    const proto = input.localName === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    // Element focus/blur events can be absent in an inactive document.
    // Supply only missing events, and never bring Chrome to the foreground.
    const seen = new Set();
    const capture = (event) => { if (event.target === input) seen.add(event.type); };
    const types = ["focus", "focusin", "blur", "focusout"];
    for (const type of types) input.addEventListener(type, capture);
    const emitMissing = (type) => {
      if (!seen.has(type)) input.dispatchEvent(new FocusEvent(type, { bubbles: type === "focusin" || type === "focusout", composed: true }));
    };
    try {
      input.focus({ preventScroll: true });
      emitMissing("focus");
      emitMissing("focusin");
      setter.call(input, text);
      input.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: text }));
      input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      // Never send Enter: it could submit the whole dialog.
      input.blur();
      emitMissing("blur");
      emitMissing("focusout");
    } finally {
      for (const type of types) input.removeEventListener(type, capture);
    }
  }

  const waitFor = (check, options) => root.MidrollWait.waitFor(check, options);

  async function createAdapter({ signal, onDurationStatus = () => {}, timeout = 10000 } = {}) {
    const { scope } = editorScope();
    const route = location.pathname;
    const videoId = route.match(/^\/video\/([A-Za-z0-9_-]+)\//)?.[1];
    if (!videoId) throw new Error("Hãy mở một video trong YouTube Studio rồi mở Quản lý vị trí quảng cáo để tự đọc độ dài.");
    const started = Date.now();
    let duration = null;
    let source = "studio";
    let lastReason = "metadata-pending";

    function assertContext() {
      if (location.pathname !== route || !scope.isConnected || !visible(scope)) {
        throw new Error("Bạn đã đổi video hoặc đóng trình quảng cáo. Đã dừng; hãy mở lại và Xem trước.");
      }
      const current = editorScope();
      if (current.scope !== scope) throw new Error("Trình quảng cáo đã được mở lại. Hãy Xem trước lại.");
      return current.insert;
    }

    while (Date.now() - started < timeout) {
      signal?.throwIfAborted();
      assertContext();
      onDurationStatus("Đang tự đọc tổng độ dài video từ YouTube Studio…");
      let metadata;
      let readerTimer;
      try {
        metadata = await Promise.race([
          chrome.runtime.sendMessage({ type: "MIDROLL_READ_DURATION" }),
          new Promise((resolve) => { readerTimer = setTimeout(() => resolve({ seconds: null, reason: "reader-unavailable" }), 1500); })
        ]);
      } catch { metadata = { seconds: null, reason: "reader-unavailable" }; }
      finally { clearTimeout(readerTimer); }
      signal?.throwIfAborted();
      assertContext();
      if (metadata?.videoId === videoId && Number.isFinite(metadata.seconds) && metadata.seconds > 0) {
        duration = metadata.seconds;
        source = "player";
        break;
      }
      lastReason = metadata?.reason || "metadata-pending";
      // Conflicting identity-checked metadata must not be replaced by a
      // guessed UI time. A wrong-video response is never trusted.
      if (lastReason !== "duration-conflict") {
        try { duration = automaticDuration(scope); } catch { lastReason = "duration-conflict"; }
        if (duration !== null) break;
      }
      await new Promise((resolve) => setTimeout(resolve, 300));
    }
    if (duration === null) throw new Error(lastReason === "duration-conflict"
      ? "Các nguồn Studio báo độ dài video khác nhau. Chưa thay đổi điểm nào; hãy tải lại tab Studio rồi thử lại."
      : "Studio chưa cung cấp được tổng độ dài video. Chưa thay đổi điểm nào; hãy tải lại tab, mở Quản lý vị trí quảng cáo và bấm Xem trước để extension tự đọc lại.");

    function snapshot(allowLocked = false) {
      const insert = assertContext();
      const rows = adRows(scope, allowLocked);
      const keys = rows.map((row) => row.raw);
      const times = rows.map((row) => row.seconds);
      const outside = rows.find((row) => row.seconds > duration);
      if (outside) throw new Error(`Điểm có sẵn ${outside.raw} được đọc là ${P.formatTime(outside.seconds)}, vượt tổng độ dài ${P.formatTime(duration)} đọc từ Studio. Chưa thay đổi điểm nào; hãy kiểm tra định dạng mốc và video.`);
      return { rows, keys, times, insert, duration, source, fingerprint: JSON.stringify([route, duration, [...keys].sort()]) };
    }

    function cleanupSnapshot() {
      const current = snapshot(true);
      const rows = cleanupRows(scope, current.rows);
      return { ...current, rows, cleanupFingerprint: JSON.stringify([route, duration, root.MidrollCleanup.signature(rows)]) };
    }

    async function removePoint(targetKey, { signal, expectedFingerprint, onWaiting = () => {} } = {}) {
      await readyToConfirm({ signal, onPending: onWaiting });
      signal?.throwIfAborted();
      const before = cleanupSnapshot();
      if (before.cleanupFingerprint !== expectedFingerprint) throw new Error("Danh sách hoặc cảnh báo đã thay đổi trước khi xóa. Hãy Xem trước dọn lại.");
      const index = before.rows.findIndex((row) => root.MidrollCleanup.key(row) === targetKey && row.kind === "manual" && !row.pending);
      if (index < 0 || !enabled(before.rows[index].remove)) throw new Error("Không nhận diện được nút xóa của điểm thủ công đã chọn. Chưa xóa điểm này.");
      const expected = root.MidrollCleanup.signature(before.rows.filter((_, i) => i !== index));
      // Resolve fresh controls and click once; a rerender must never cause
      // a second click on the next row or an automatic slot.
      before.rows[index].remove.click();
      await waitFor(() => {
        const after = cleanupSnapshot();
        return !document.hidden && after.rows.length === before.rows.length - 1 && root.MidrollCleanup.signature(after.rows) === expected && after.cleanupFingerprint;
      }, { signal, stableFor: 400, backgroundTimeout: Infinity, onPending: onWaiting,
        timeoutMessage: "Studio chưa xác nhận đúng điểm vừa xóa. Đã dừng, không bấm xóa lại và chưa lưu; hãy kiểm tra danh sách." });
    }

    async function verifyCleanup(expected, { signal } = {}) {
      await waitFor(() => !document.hidden && cleanupSnapshot().cleanupFingerprint === expected && expected, {
        signal, stableFor: 400, backgroundTimeout: Infinity,
        timeoutMessage: "Danh sách đã thay đổi sau khi dọn. Đã dừng; kiểm tra lại trước khi lưu."
      });
    }

    async function readyToConfirm({ signal, onPending } = {}) {
      // Studio's renderer may pause while fully hidden. Keep the same
      // pending operation instead of treating a self-assigned value as saved.
      await waitFor(() => { assertContext(); return !document.hidden; }, {
        signal, backgroundTimeout: Infinity, onPending
      });
    }

    async function insert(seconds, { signal, onWaiting = () => {} } = {}) {
      await readyToConfirm({ signal, onPending: onWaiting });
      const before = snapshot();
      const insertionStarted = performance.now();
      lastInsertion = { target: P.formatTime(seconds), beforeCount: before.rows.length, phase: "seek", seek: null };
      if (!enabled(before.insert)) throw new Error("Nút Chèn vị trí quảng cáo đang bị khóa. Hãy kiểm tra Studio.");
      // When a separate playhead field exists, move it to the intended time.
      // Row inputs are excluded so an existing ad time cannot be overwritten.
      const playheads = fields(scope).filter((field) => !durationLabel(field) && !before.rows.some((row) => row.input === field));
      if (playheads.length > 1) throw new Error("Có nhiều ô thời gian ngoài danh sách quảng cáo. Không thể chọn chắc chắn ô đặt vị trí; đã dừng.");
      if (playheads.length === 1 && enabled(playheads[0]) && !playheads[0].readOnly) {
        setTime(playheads[0], seconds);
      }
      // An input value is not proof that Studio moved its timeline cursor.
      // Seek the actual preview when a supported player is available.
      const editorToken = crypto.randomUUID();
      scope.setAttribute("data-midroll-editor-token", editorToken);
      let seekTimer;
      let seek;
      try {
        seek = await Promise.race([
          chrome.runtime.sendMessage({ type: "MIDROLL_SEEK_PLAYHEAD", videoId, seconds, duration, editorToken }),
          new Promise((resolve) => { seekTimer = setTimeout(() => resolve({ ok: false, reason: "seek-timeout" }), 3000); })
        ]);
      } catch { seek = { ok: false, reason: "seek-unavailable" }; }
      finally {
        clearTimeout(seekTimer);
        if (scope.getAttribute("data-midroll-editor-token") === editorToken) scope.removeAttribute("data-midroll-editor-token");
      }
      signal?.throwIfAborted();
      assertContext();
      lastInsertion.seek = seek?.ok ? "confirmed" : seek?.reason || "no-response";
      if (!seek?.ok && seek?.reason !== "seek-unavailable") throw new Error("Chưa xác nhận được vị trí thanh thời gian trước khi chèn. Đã dừng; chưa thêm điểm ở lượt này.");
      // The actual player acknowledgment already covers the position. Keep
      // the display-only settling check for interfaces without player support.
      if (!seek?.ok && playheads.length === 1 && enabled(playheads[0]) && !playheads[0].readOnly) {
        await waitFor(() => playheads[0].isConnected && P.readStudioTime(playheads[0].value) === seconds, { signal, stableFor: 300, onPending: onWaiting });
      }
      lastInsertion.timings = { prepareMs: Math.round(performance.now() - insertionStarted) };
      const identificationStarted = performance.now();
      const ready = snapshot();
      if (ready.fingerprint !== before.fingerprint) throw new Error("Danh sách quảng cáo đã thay đổi trước khi chèn. Hãy Xem trước lại.");
      // One click only. Never retry insertion on an ambiguous response.
      ready.insert.click();
      lastInsertion.phase = "identify";
      const oldInputs = new Set(before.rows.map((row) => row.input));
      let pendingReason = "Danh sách chưa xuất hiện điểm mới.";
      function selection() {
        assertContext();
        let current;
        try { current = adRows(scope); }
        catch (error) { pendingReason = error.message; return null; }
        if (current.length !== before.rows.length + 1) {
          pendingReason = `Danh sách đang có ${current.length} điểm; cần ${before.rows.length + 1} điểm sau một lần chèn.`;
          return null;
        }
        const keys = current.map((item) => item.raw);
        lastInsertion.currentCount = current.length;
        const extra = P.additionalKey(before.keys, keys);
        if (extra === null) {
          pendingReason = "Chưa đối chiếu được đầy đủ các mốc cũ sau khi Studio vẽ lại danh sách.";
          return null;
        }
        const fresh = current.filter((item) => !oldInputs.has(item.input));
        lastInsertion.newInputCount = fresh.length;
        lastInsertion.extraTime = extra;
        // A surviving input identity is stronger than its displayed value.
        // Otherwise require a unique occurrence of the extra raw timecode.
        const matches = current.filter((item) => item.raw === extra);
        const row = fresh.length === 1 && fresh[0].raw === extra ? fresh[0]
          : matches.length === 1 ? matches[0] : null;
        if (!row) {
          pendingReason = `Điểm mới được tạo tại vị trí thanh thời gian ${extra}, trùng điểm cũ; Studio đã thay toàn bộ các ô.${seek?.ok ? "" : " Chưa điều khiển được vị trí phát thực tế của giao diện này."}`;
          return null;
        }
        return { row, token: JSON.stringify([[...keys].sort(), current.indexOf(row), row.raw]) };
      }
      // Rerenders can expose a temporary default/duplicate or a partial list.
      // Wait for stable evidence instead of stopping on the first frame.
      const token = await waitFor(() => selection()?.token, {
        signal, timeout: 15000, stableFor: 400, onPending: onWaiting,
        timeoutMessage: () => `Không xác định chắc chắn ô mới tại mốc ${P.formatTime(seconds)} sau khi chờ Studio cập nhật. ${pendingReason} Đã dừng; chưa sửa ô chưa rõ và chưa lưu. Hãy kiểm tra điểm vừa thêm trước khi Xem trước lại.`
      });
      signal?.throwIfAborted();
      // Re-read after awaiting: the previous DOM input may be disconnected.
      const latest = selection();
      if (!latest || latest.token !== token) throw new Error(`Studio tiếp tục đổi danh sách tại mốc ${P.formatTime(seconds)}. Đã dừng; chưa sửa ô chưa rõ và chưa lưu. Hãy kiểm tra điểm vừa thêm.`);
      const row = latest.row;
      lastInsertion.timings.identifyMs = Math.round(performance.now() - identificationStarted);
      const confirmationStarted = performance.now();
      lastInsertion.phase = "edit";
      if (!enabled(row.input) || row.input.readOnly) throw new Error("Ô thời gian mới chưa cho phép nhập. Đã dừng; hãy kiểm tra điểm vừa thêm.");
      // Commit the new row itself, even if its initial displayed time matches
      // the target; the playhead display alone is not a model acknowledgment.
      setTime(row.input, seconds);
      await waitFor(() => {
        const current = snapshot();
        if (document.hidden) return false;
        return current.keys.length === before.keys.length + 1 && P.preserves(before.keys, current.keys) && current.times.includes(seconds) && current.fingerprint;
      }, { signal, stableFor: 400, backgroundTimeout: Infinity, onPending: onWaiting });
      lastInsertion.phase = "confirmed";
      lastInsertion.timings.confirmMs = Math.round(performance.now() - confirmationStarted);
      lastInsertion.timings.totalMs = Math.round(performance.now() - insertionStarted);
    }
    async function verifyPlan(plan, { signal, onWaiting = () => {} } = {}) {
      await waitFor(() => {
        const current = snapshot();
        if (document.hidden) return false;
        return plan.additions.every((seconds) => current.times.some((time) => Math.abs(time - seconds) <= P.DUPLICATE_WINDOW)) && current.fingerprint;
      }, { signal, stableFor: 400, backgroundTimeout: Infinity, onPending: onWaiting });
    }
    return { snapshot, insert, verifyPlan, cleanupSnapshot, removePoint, verifyCleanup };
  }

  // Diagnostics contain only controls in the ad dialog, not video titles,
  // account identifiers, cookies, URLs, HTML dumps, or page-wide content.
  function diagnostics() {
    const { scope } = editorScope();
    return {
      version: "0.1.10",
      lastInsertion,
      editor: scope.localName,
      controls: query(scope, BUTTONS).filter(visible).map((node) => ({ tag: node.localName, label: node.getAttribute("aria-label") || node.getAttribute("title") || node.textContent.trim().slice(0, 100) })),
      timeFields: query(scope, INPUTS).filter(visible).map((node) => ({ tag: node.localName, label: node.getAttribute("aria-label") || "", value: P.readStudioTime(node.value) === null ? "(không phải thời gian)" : node.value })),
      adRows: cleanupRows(scope, adRows(scope, true)).map((row) => ({ raw: row.raw, kind: row.kind, warning: row.warning, pending: row.pending,
        markers: [row.element, ...query(row.element, '[icon], [aria-label], [title], [data-ad-type]')].map((node) => ({ tag: node.localName, icon: node.getAttribute("icon"), label: node.getAttribute("aria-label") || node.getAttribute("title"), type: node.getAttribute("data-ad-type") })) }))
    };
  }
  function isEditorOpen() { try { editorScope(); return true; } catch { return false; } }
  root.MidrollStudio = { createAdapter, diagnostics, mountPanel, isEditorOpen };
})(globalThis);
