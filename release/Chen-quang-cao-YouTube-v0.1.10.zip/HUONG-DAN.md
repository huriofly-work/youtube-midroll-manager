# Chèn và dọn điểm quảng cáo YouTube — bản 0.1.10

Extension dành cho Chrome từ bản 118, YouTube Studio tiếng Việt, xử lý một video đang mở.

## Cài vào Chrome

1. Nếu dùng ZIP, giải nén ra một thư mục cố định. Thư mục cần có `manifest.json` ngay bên trong.
2. Mở `chrome://extensions` bằng thanh địa chỉ Chrome.
3. Bật **Chế độ dành cho nhà phát triển** ở góc trên bên phải.
4. Chọn **Tải tiện ích đã giải nén** / **Load unpacked**.
5. Chọn thư mục `extension` trong mã nguồn, hoặc thư mục đã giải nén có `manifest.json`.
6. Trong menu tiện ích hình mảnh ghép, ghim **Chèn điểm quảng cáo YouTube**.

Bản này cần thêm quyền **debugger** để giữ tab Studio hoạt động khi bạn dùng ứng dụng khác. Nếu Chrome yêu cầu chấp nhận quyền mới hoặc bật lại tiện ích sau cập nhật, hãy thực hiện trước khi sử dụng. Chrome sẽ hiện thanh thông báo tiện ích đang điều khiển trình duyệt trong lúc chèn; thanh thông báo biến mất khi phiên điều khiển kết thúc.

Không cần Node.js, cài thư viện, API key, OAuth hoặc đăng nhập thêm. Chrome dùng phiên YouTube Studio mà bạn đã đăng nhập.

## Sử dụng

1. Mở một video đã bật kiếm tiền và dài tối thiểu 8 phút trong YouTube Studio.
2. Vào **Kiếm tiền → Quản lý vị trí quảng cáo**, mở trình chỉnh sửa có nút **Chèn vị trí quảng cáo**.
3. Bấm biểu tượng extension trên thanh công cụ Chrome để mở bảng điều khiển. Chọn tab **Chèn điểm**.
4. Nhập **Đoạn đầu không chèn (giây)**, **Đoạn cuối không chèn (giây)** và **Khoảng cách giữa các điểm (giây)**. Đoạn đầu/cuối cho phép 0; khoảng cách phải lớn hơn 0. Đoạn cuối được tính lùi từ cuối video. Ban đầu hai đoạn là 60 giây, khoảng cách là 120 giây; bạn có thể đổi. Hai nút **−/+** đổi đúng 1 giây mỗi lần nhấn. Extension nhớ các giá trị đã dùng khi xem trước.
5. **Độ dài video · tự động** hiển thị tổng thời gian do extension tự đọc. Không cần nhập thời lượng. Bảng tự chờ dữ liệu tải; thường hiển thị ngay khi mở.
6. Bấm **Xem trước** để đọc độ dài và các điểm hiện có, rồi xem các mốc sẽ thêm.
7. Bấm **Chèn điểm**. Giữ nguyên video và trình chỉnh sửa trong lúc chạy. Có thể bấm **Dừng**.
8. Xem lại toàn bộ các điểm trong Studio. Tự bấm **Tiếp tục/Lưu** theo các nút của YouTube Studio để hoàn tất.

## Hai tab và tải lại dữ liệu

**Chèn điểm** chứa đoạn đầu/cuối, khoảng cách lưới và thao tác chèn. **Dọn điểm** chứa khoảng cách tối thiểu và thao tác dọn. Chuyển tab giữ các ô đã nhập, bỏ kế hoạch xem trước cũ và đọc lại dữ liệu cho chức năng đang chọn. Có thể dùng phím mũi tên trái/phải hoặc Home/End khi đang chọn nút tab.

Nút **Tải lại dữ liệu** đọc lại thời lượng, danh sách điểm và cảnh báo đang hiển thị trong Studio. Nó giữ cài đặt đã nhập và không tải lại trang, không thêm/xóa/lưu điểm. Sau khi tải, bấm **Xem trước** hoặc **Xem trước dọn** để tính kế hoạch mới. Nút này không yêu cầu YouTube xét duyệt lại hay ép máy chủ cập nhật; dữ liệu phải có trong Studio. Khi đang chèn/dọn, nút tải và hai tab bị khóa để bảo toàn lượt chạy.

## Dọn điểm sau khi YouTube xét duyệt

1. Sau khi chèn, tự lưu trong Studio và đợi YouTube xét duyệt xong. Mở lại **Quản lý vị trí quảng cáo** và extension, chọn tab **Dọn điểm**.
2. Nhập **Khoảng cách tối thiểu khi dọn (giây)** bằng số nguyên lớn hơn 0. Đây là giá trị riêng, không phải khoảng cách lưới lúc chèn.
3. Bấm **Tải lại dữ liệu** nếu cảnh báo hoặc danh sách vừa thay đổi. Không cần đánh dấu checkbox. Bảng không tự biết một điểm không có cảnh báo đã được xét duyệt hay chưa.
4. Bấm **Xem trước dọn**. Chưa xóa gì ở bước này. Kiểm tra từng mốc và lý do sẽ xóa.
5. Bấm **Dọn điểm**, đợi hoàn tất rồi kiểm tra toàn bộ danh sách. Tự bấm **Tiếp tục/Lưu**.

Quy tắc dọn áp dụng cho tất cả điểm thủ công, kể cả điểm có sẵn. Điểm có cảnh báo chất lượng của YouTube (chữ cảnh báo hoặc biểu tượng warning màu đỏ trong chính hàng) được chọn xóa trước. Các điểm thủ công không có cảnh báo được xét theo thời gian tăng dần; giữ điểm sớm hơn, xóa điểm sau nếu khoảng cách nhỏ hơn mức bạn nhập. Khoảng cách đúng bằng mức tối thiểu được giữ, có đối chiếu phần nhỏ giây ở ranh giới mà không giả định tốc độ khung hình.

Mọi điểm tự động được giữ. Điểm thủ công quá gần một điểm tự động được chọn xóa dù nằm trước điểm tự động. Nếu các điểm tự động gần nhau, extension vẫn giữ chúng, nên không cam kết mọi điểm trong video đều cách nhau đủ mức tối thiểu. Điểm đang xét duyệt hoặc chưa xác định được loại được giữ và không dùng để loại điểm thủ công khác.

Extension chỉ nhận diện thủ công/tự động qua nhãn trong hàng hoặc tiêu đề/nhãn nhóm danh sách; không coi mọi điểm có nút xóa là thủ công. Nếu chưa nhận diện được, bảng báo số điểm chưa rõ và giữ nguyên. Nếu tất cả điểm đều chưa rõ, nút sao chép thông tin lỗi giúp báo cấu trúc đang gặp. Khi cảnh báo hoặc danh sách thay đổi sau xem trước, extension dừng và yêu cầu xem trước lại. Sau mỗi lần xóa chỉ xác nhận khi đúng một điểm đã mất và mọi điểm khác còn nguyên; không bấm xóa lại khi kết quả chưa rõ.

Theo [YouTube Trợ giúp](https://support.google.com/youtube/answer/6175006?hl=vi), phản hồi ban đầu thường xuất hiện trong vòng một giờ nhưng có thể lâu hơn; chỉnh sửa sau phản hồi ban đầu thường nhận kết quả nhanh hơn. Dấu cảnh báo cho biết ít có khả năng phân phát quảng cáo. Không có cảnh báo cũng không bảo đảm quảng cáo sẽ chạy.

## Mở extension ở trang khác

Bấm biểu tượng extension luôn mở giao diện. Nếu đang ở trang khác, trang Chrome nội bộ hoặc danh sách video Studio, popup sẽ hướng dẫn mở đúng video và có nút **Mở YouTube Studio** (mở tab mới khi bạn bấm). Không chỉ hiện dấu chấm than ở icon.

Nếu đang ở trang của một video Studio, popup mở bảng điều khiển trên trang rồi tự đóng. Nếu chưa mở **Quản lý vị trí quảng cáo**, bảng sẽ hướng dẫn mở hộp này rồi bấm **Xem trước**; chưa thêm điểm nào. Nếu không mở được bảng do sự cố, popup hiện lỗi cùng nút **Thử lại** và **Sao chép thông tin lỗi**.

## Chuyển sang ứng dụng khác trong lúc chèn

Khi bấm **Chèn điểm**, extension tự bật chế độ giữ tab Studio hoạt động bằng cơ chế của Chrome. Sau đó bạn có thể chuyển sang ứng dụng khác hoặc thu nhỏ Chrome. Extension không tự đưa cửa sổ lên trước, không đổi tab đang chọn và không điều khiển chuột/bàn phím toàn máy. Mỗi mốc được đọc lại và chờ ổn định trước khi chuyển sang mốc kế tiếp; danh sách được kiểm tra lại trước khi báo hoàn tất.

Phiên giữ tab hoạt động chỉ gắn với tab video đang xử lý và tự ngắt khi xong hoặc dừng. Chrome yêu cầu quyền debugger và hiện thanh thông báo; tab vẫn dùng CPU/RAM để thực hiện công việc. Máy phải còn thức và Chrome phải còn chạy. Giữ video và hộp quản lý quảng cáo mở trong lúc chạy.

Nếu bấm **Hủy** trên thanh thông báo Chrome hoặc mở DevTools của tab Studio, Chrome có thể ngắt phiên; extension dừng và báo kiểm tra điểm cuối. Để dừng bình thường, bấm **Dừng**. Nếu không bật được phiên, chưa chèn điểm nào; đóng DevTools của tab đó và kiểm tra quyền extension trước khi thử lại. Nếu Chrome vẫn tạm ngừng trang, bộ chờ tiếp tục bảo toàn thao tác dang dở thay vì bỏ mốc hoặc chèn lại.

Nếu bản cũ đã làm thiếu mốc, sau khi cập nhật hãy **Xem trước** lại rồi chèn phần còn thiếu. Những mốc gần/trùng điểm đang có được bỏ qua. Kiểm tra cả điểm mặc định do lần chạy cũ tạo ra trước khi lưu; extension giữ các điểm đó theo quy tắc giữ điểm cũ.

## Quy tắc

- Mốc đầu tiên bằng **Đoạn đầu không chèn**. Các mốc tiếp theo tiếp tục cộng khoảng cách.
- Chỉ thêm mốc không muộn hơn `thời lượng video - đoạn cuối không chèn`, và luôn trước thời điểm video kết thúc. Tổng hai đoạn phải nhỏ hơn thời lượng video.
- Ví dụ video 10 phút, đoạn đầu 90 giây, đoạn cuối 150 giây và khoảng cách 120 giây: **01:30, 03:30, 05:30, 07:30**.
- Giữ các điểm hiện có, kể cả điểm nằm trong phút đầu/cuối. Nếu có điểm cũ ở mốc dự kiến hoặc lệch không quá 1 giây, bỏ qua mốc dự kiến đó. Khoảng cách áp dụng cho lưới mốc mới, không dời các điểm cũ để ép toàn bộ danh sách cách đều.
- Không thay đổi lựa chọn quảng cáo tự động của YouTube. Luồng chèn không xóa điểm. Chỉ luồng **Dọn điểm** được xóa những điểm thủ công đã xem trước. Không tự bấm Tiếp tục hoặc Lưu.
- Chỉ sửa ô thời gian thuộc điểm vừa thêm. Kiểm tra số điểm và các mốc cũ sau mỗi lần chèn.
- Tối đa 1.000 mốc dự kiến trong một lần xem trước. Nếu vượt giới hạn, tăng khoảng cách.

## Vị trí thanh thời gian và danh sách vẽ lại

Nút chèn của Studio tạo điểm tại vị trí thanh thời gian đang đứng. Bản 0.1.6 thử điều khiển vị trí phát thực tế của preview đúng video trước mỗi lần chèn, thay vì chỉ nhập ô thời gian hiển thị. Preview được tạm dừng để vị trí không chạy tiếp; extension không phát video. Khi player đã nhận diện không xác nhận được vị trí mới, lượt đó dừng trước khi tạo điểm.

Sau khi chèn, extension chờ danh sách ổn định và đối chiếu đầy đủ số lần xuất hiện của các mốc cũ, kể cả mốc trùng. Dùng ô mới có danh tính DOM còn giữ được, hoặc một mốc thừa xuất hiện duy nhất sau khi đối chiếu. Không chọn ô theo thứ tự cuối danh sách hoặc lấy đại một ô trùng.

Nếu giao diện không có player hỗ trợ và Studio thay tất cả các ô trong khi điểm mới trùng mốc cũ, không thể xác định an toàn ô cần sửa chỉ từ các giá trị thời gian. Extension chờ tối đa 15 giây xử lý khi trang đang hoạt động, sau đó dừng và báo mốc dự kiến cùng vị trí thanh timeline đã tạo điểm. Kiểm tra điểm vừa thêm trước khi chạy lại. Con số “đã xác nhận thêm” là số lượt đã kiểm tra xong, không phải giới hạn số điểm và không bao gồm lượt đang lỗi.

## Tốc độ chèn

Bản 0.1.7 giảm công việc quét danh sách khi có nhiều điểm và bỏ lượt chờ riêng cho ô hiển thị nếu player thực tế đã xác nhận vị trí mới. Vẫn chờ danh sách ổn định và mốc mới được ghi nhận, mỗi bước ít nhất 400 ms, rồi kiểm tra danh sách cuối. Chèn theo thứ tự từng điểm để tránh sửa nhầm khi Studio dựng lại giao diện.

Phép đo trên trang mô phỏng có 200 điểm cũ cho thời gian khoảng 1,19 giây/mốc, so với 1,76 giây/mốc của 0.1.6, bao gồm phần kiểm tra danh sách cuối khi thêm 5 mốc. Tốc độ trên Studio thật phụ thuộc thời gian dựng giao diện và tải/di chuyển preview; không bảo đảm cùng mức tăng. Giữ các điểm cũ, quảng cáo tự động và việc tự bấm Lưu như các bản trước.

## Khi không đọc được thời lượng hoặc giao diện

Extension ưu tiên độ dài từ trình phát hoặc dữ liệu video có ID khớp với video đang mở, rồi đọc bộ đếm tổng thời gian trong Studio nếu cần. Bộ đọc chỉ truy cập các trường và hàm đọc độ dài; không phát video, phân tích cảnh/âm thanh hay tải video về. Không suy đoán tổng độ dài từ vị trí phát hoặc mốc quảng cáo cuối.

Nếu dữ liệu chưa có, bảng tự thử lại trong khoảng 10 giây. Nếu vẫn báo **Chưa đọc được**, tải lại tab Studio bằng F5, mở lại **Quản lý vị trí quảng cáo** rồi bấm biểu tượng extension hoặc **Xem trước**. Không cần nhập thời lượng tay. Nếu các nguồn dữ liệu có ID đúng báo độ dài khác nhau, extension dừng để tránh chèn sai.

Các ô thời gian quảng cáo trong Studio dùng định dạng khác: `1:07:17` là 1 phút 7 giây kèm phần nhỏ của giây; không phải 1 giờ 7 phút 17 giây. Extension đọc và ghi mốc ba phần này; mốc bốn phần dùng giờ:phút:giây:phần nhỏ giây. Khi chèn, extension giữ nguyên văn bản ở các điểm cũ và so sánh phần giây nguyên để bỏ qua mốc trùng. Khi dọn, phần nhỏ giây được đối chiếu thêm ở ranh giới khoảng cách tối thiểu; không giả định tốc độ khung hình.

Nếu thông báo vẫn nói một điểm vượt độ dài video, bản mới hiển thị chính xác mốc đang đọc và độ dài đang dùng. Extension dừng để tránh chèn với dữ liệu chưa rõ; không xóa hay đổi các điểm đó để bỏ qua lỗi.

## Cập nhật từ bản cũ

Lưu các thay đổi muốn giữ trước khi làm mới Studio. Giải nén ZIP 0.1.10 để thay các tệp trong đúng thư mục đã cài. Mở `chrome://extensions`, tìm extension và bấm **Tải lại** (biểu tượng mũi tên vòng tròn). Chấp nhận quyền debugger/bật lại extension nếu Chrome yêu cầu. Sau đó F5 tab Studio, mở lại Quản lý vị trí quảng cáo, rồi bấm biểu tượng extension. Kiểm tra dòng nhỏ trên bảng có **v0.1.10**.

Nếu cài từ thư mục mã nguồn `extension`, các tệp trong thư mục đó đã được cập nhật; chỉ cần Tải lại extension và F5 tab Studio.

Bảng điều khiển nằm bên trong hộp quảng cáo để tránh bàn phím bị hộp thoại giữ ở ô Studio. Đã kiểm tra bằng thao tác click và gõ phím thật trên trang mô phỏng có focus trap, hộp thoại modal và phím tắt toàn trang. Không cần tắt tính năng giữ focus của Studio.

Nếu extension không nhận diện được nút chèn hoặc ô thời gian, nó dừng. Không chèn lại tự động sau một thao tác có kết quả không rõ. Một điểm vừa tạo có thể vẫn đang ở vị trí mặc định; kiểm tra cả điểm cuối trước khi lưu hoặc chạy lại. Dừng/chạy lỗi không tự hoàn tác các điểm đã thêm. Bạn có thể tiếp tục chỉnh thủ công trong Studio hoặc dùng thao tác hủy bản chỉnh sửa của Studio nếu muốn bỏ thay đổi.

Không còn mục hỗ trợ thường trực. Khi có lỗi, nút **Sao chép thông tin lỗi** xuất hiện ngay dưới thông báo. Bấm nút nếu cần gửi thông tin để báo lỗi; chỉ sao chép vào clipboard, không tự gửi đi. Khi lỗi được khắc phục hoặc bắt đầu thao tác mới, nút sẽ ẩn.

Nếu Chrome chặn sao chép, một ô chỉ đọc hiện ra với thông tin được chọn sẵn. Nhấn **Ctrl+C** để sao chép. Thông báo lỗi gốc vẫn được giữ để bạn xem lại. Khi chưa mở hộp quảng cáo hoặc dừng theo yêu cầu, bảng chỉ hướng dẫn trạng thái và không hiện nút sao chép lỗi.

Khi báo lỗi chèn, thông tin còn có mục `lastInsertion`: mốc cần thêm, số ô trước/sau, giai đoạn đang xử lý và kết quả điều khiển vị trí phát (`seek`). Bản 0.1.7 bổ sung `timings`: thời gian chuẩn bị/seek, nhận diện ô mới, xác nhận mốc và tổng lượt chèn, tính bằng ms cho lượt đã hoàn tất. Mục này giúp phân biệt thanh timeline chưa di chuyển với danh sách đang dựng lại, không kèm ID tài khoản hoặc video.

Bản 0.1.8 hiển thị hướng dẫn/lỗi trong popup hoặc bảng điều khiển, không dùng dấu `!` ở icon. Sau khi cập nhật extension trong Chrome, làm mới tab Studio trước khi dùng bản mới.

## Quyền và dữ liệu

Dùng `activeTab`, `scripting`, `storage`, `debugger`: mở bảng theo lần bấm biểu tượng, chạy mã đóng gói, lưu các khoảng thời gian trên máy và giữ tab Studio hoạt động trong lượt chèn hoặc dọn. Debugger là quyền mạnh của Chrome, không thể khai báo thành quyền tùy chọn. Mã quản lý phiên kiểm tra nguồn gửi, khung chính, ID tab/video và mã lượt chạy; chỉ dùng lệnh giữ focus của trang cùng lệnh đưa vòng đời trang về active. Không nhận lệnh CDP tùy ý từ trang.

Bộ đọc độ dài chỉ trả về độ dài và nguồn đọc. Bộ điều khiển vị trí phát chạy riêng khi chèn, chỉ gọi pauseVideo/seekTo/getCurrentTime/getDuration trên player có ID đúng video, hoặc điều khiển một video native có độ dài khớp trong đúng hộp đang mở. Không đọc cookie, token đăng nhập hoặc lịch sử; không máy chủ riêng, không tải mã từ mạng, không gọi API nội bộ YouTube. Khi mất heartbeat hơn 45 giây hoặc chuyển/tải lại trang, bộ quản lý ngắt phiên. Nếu ngắt thất bại tạm thời, giữ quyền sở hữu phiên và thử dọn lại.

Tham khảo [chrome.debugger](https://developer.chrome.com/docs/extensions/reference/api/debugger), [giới hạn quyền tùy chọn](https://developer.chrome.com/docs/extensions/reference/api/permissions), [giao thức focus emulation](https://chromedevtools.github.io/devtools-protocol/tot/Emulation/#method-setFocusEmulationEnabled).

Các phương thức pauseVideo, seekTo và getCurrentTime được mô tả trong [YouTube Player API](https://developers.google.com/youtube/iframe_api_reference). Tài liệu này không bảo đảm Studio cung cấp cùng giao diện điều khiển; tiện ích chỉ dùng khi thực sự tìm thấy player phù hợp.

## Trạng thái kiểm chứng

Kết quả kiểm thử được ghi trong `artifacts/VERIFICATION.md` của mã nguồn. **Chưa kiểm thử trên tài khoản YouTube Studio thật** trong phiên phát triển này; cấu trúc Studio có thể khác trang mô phỏng. Thông báo hoàn tất nghĩa là các mốc đã đọc lại đúng trong trình chỉnh sửa; chưa phải xác nhận YouTube đã lưu hay phân phát quảng cáo.

Theo [YouTube Trợ giúp](https://support.google.com/youtube/answer/6175006?hl=vi), video kiếm tiền cần dài tối thiểu 8 phút để đặt quảng cáo giữa video; các điểm chèn không nhất định phân phát quảng cáo.
